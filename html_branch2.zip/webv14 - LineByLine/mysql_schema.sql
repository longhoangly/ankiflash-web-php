

mysql> create database anki;
mysql> create table tblFlashcards
(
	flsPk int NOT NULL AUTO_INCREMENT PRIMARY KEY,
	flsWord varchar(25) NOT NULL,
	flsWordType varchar(25),
	flsPhonetic varchar(25),
	flsExample varchar(1000),
	flsSound_uk varchar(50),
	flsSound_us varchar(50),
	flsThumb varchar(300) NOT NULL,
	flsImg varchar(300) NOT NULL,
	flsEntryContent varchar(131072) NOT NULL,
	flsTag varchar(5),
	flsCopyRight varchar(300) NOT NULL,
	flsAnkiDeck varchar(131072) NOT NULL,
	flsCreatedTime TIMESTAMP DEFAULT NOW(),
	flsLastQueryTime TIMESTAMP
); 

mysql> drop table tblFlashcards;

mysql> insert into tblFlashcards (flsWord, flsWordType, flsPhonetic, flsExample, flsSound_uk, flsSound_us, flsThumb, flsImg, flsEntryContent, flsTag, flsCopyRight, flsAnkiDeck, flsLastQueryTime) values ($word, $wordType, $phonetic, $example, $sound_uks[0], $sound_us[0], $thumb, $img, $entryContent, $tag, $copyRight, $ankiDeck, NOW());

mysql> insert into tblFlashcards (flsWord) values($word);
mysql> insert into tblFlashcards (flsWordType) values($wordType) where flsWord="$word";
mysql> insert into tblFlashcards (flsPhonetic) values($phonetic) where flsWord="$word";
mysql> insert into tblFlashcards (flsExample) values($example) where flsWord="$word";
mysql> insert into tblFlashcards (flsSound_uk) values($sound_uks[0]) where flsWord="$word";
mysql> insert into tblFlashcards (flsSound_us) values($sound_us[0]) where flsWord="$word";
mysql> insert into tblFlashcards (flsThumb) values($thumb) where flsWord="$word";
mysql> insert into tblFlashcards (flsImg) values($img) where flsWord="$word";
mysql> insert into tblFlashcards (flsEntryContent) values($entryContent) where flsWord="$word";
mysql> insert into tblFlashcards (flsTag) values($tag) where flsWord="$word";
mysql> insert into tblFlashcards (flsCopyRight) values($copyRight) where flsWord="$word";
mysql> insert into tblFlashcards (flsAnkiDeck) values($ankiDeck) where flsWord="$word";
mysql> insert into tblFlashcards (flsLastQueryTime) values(NOW()) where flsWord="$word";
