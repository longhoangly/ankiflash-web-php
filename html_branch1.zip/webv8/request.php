<?php
error_reporting(E_ERROR);

session_start();
$sid = substr(session_id(), -8);

// get the q parameter from URL
$q = $_REQUEST["q"];


if($q=="init"){

	recursiveRemoveDirectory("$sid");
	unlink("archive_$sid.zip");
	sleep(1);
	mkdir("$sid", 0777, true);
	sleep(1);
	mkdir("$sid/images", 0777, true);
	mkdir("$sid/sounds", 0777, true);
	mkdir("$sid/htmls", 0777, true);
	
}else if($q=="clear"){

	recursiveRemoveDirectory("$sid");
	unlink("archive_$sid.zip");

}else if($q=="download"){

	$directories = array("icons", "oxlayout", "cardform", $sid);
	$archivName = "archive_$sid.zip";
	
	$zipObj = new ZipArchive;
	$zipObj->open($archivName, ZipArchive::CREATE);
	zpr($directories, $archivName, "complete", $zipObj);
	$zipObj->close();
	
	sleep(1);
	$result = '<a href="http://localhost/html/' . "archive_$sid.zip" . '" style="font-size: 15px; color: blue">Download Archived Flashcard</a>';
	echo $result;
	
}else{

	$url = "http://www.oxfordlearnersdictionaries.com/search/english/direct/?q=" . $q;
	$content = getContent($url);
	
	// create the DOMDocument object, and load HTML from $content
	$dochtml = new DOMDocument();
	$dochtml->loadHTML($content);
	
	// create the DOMXpath object, and load HTML from $strhtml
	$xpath = new DOMXpath($dochtml);
		
	// GET WORD
	$varWords = $xpath->query('//h2[@class="h"]', $entryContentHTML);
	$word = $varWords->item(0)->nodeValue;
		
	// GET WORD TYPE
	$varWordTypes = $xpath->query('//span[@class="pos"]', $entryContentHTML);
	$wordType = $varWordTypes->item(0)->nodeValue;
	if(isset($wordType)){
		$wordType = "($wordType)";
	}
	
	// GET PHONETIC
	$varPhonetics = $xpath->query('//span[@class="phon"]', $entryContentHTML);
	$phonetics = getPhonetics($varPhonetics);
	$phonetic = "BrE &nbsp" . $phonetics[0] . "&nbsp &nbsp &nbsp" . "NAmE &nbsp" . $phonetics[1];
		
	// GET EXAMPLES
	$varExamples = $xpath->query('//span[@class="x-g"]', $entryContentHTML);
	$examples = getExamples($varExamples);
	$example = $examples[0] . $examples[1] . $examples[2] . $examples[3];
	$example = '<link type="text/css" rel="stylesheet" href="./oxlayout/oxford.css">' . $example;
	$example = preg_replace("/$word/i", "{{c1::$word}}", $example);
	//$example = '<div class="responsive_entry_center_wrap" style="padding: 5px">' . $example . '</div>';
		
	// GET PRONUNCIATION SOUND FILES
	$query_uk = $xpath->query('//div[@class="sound audio_play_button pron-uk icon-audio"]', $entryContentHTML);
	$sound_uks = getSounds($query_uk, $sid);
	$query_us = $xpath->query('//div[@class="sound audio_play_button pron-us icon-audio"]', $entryContentHTML);
	$sound_us = getSounds($query_us, $sid);
		
	// GET IMAGE FILES
	// get the element with tag="img"
	$imgsContentHTML = $dochtml->getElementById('ox-enlarge');
	$img = $thumb = "";
	
	$imgs = getImages($imgsContentHTML, 'a', 'href', $sid);
	if(isset($imgs[0])){
		$img = $imgs[0];
	}else{
		$img = '<a href="https://www.google.com.vn/search?biw=1280&bih=661&tbm=isch&sa=1&q=' . $word . '" style="font-size: 15px; color: blue">Images for the word: ' . $word . '</a>';		
	}
	
	$thumbs = getImages($imgsContentHTML, 'img', 'src', $sid);
	if(isset($thumbs[0])){
		$thumb = $thumbs[0];
	}else{
		$thumb = '<a href="https://www.google.com.vn/search?biw=1280&bih=661&tbm=isch&sa=1&q=' . $word . '" style="font-size: 15px; color: blue">Images for this word</a>';
	}
		
	// GET ENTRY CONTENT FROM OXFORD DICTIONARY
	// get the element with id="entryContent"
	$entryContentHTML = $dochtml->getElementById('entryContent');
	
	// uses innerHTML() to get the HTML content from $entryContent
	if (isset($entryContentHTML )){
		$entryContent = innerHTML($entryContentHTML);
	} else {
		$entryContent = "This word does not exist...!";
	}
	
	// link css and javascript file into entryContent div
	$entryContent = '<html>' .
	'<meta http-equiv="Content-Type" content="text/html; charset=utf-8">' . 
	'<link type="text/css" rel="stylesheet" href="./oxlayout/oxford.css">' . 
	'<link type="text/css" rel="stylesheet" href="./oxlayout/interface.css">' . 
	'<link type="text/css" rel="stylesheet" href="./oxlayout/responsive.css">' .
	'<div id="entryContent" class="responsive_entry_center_wrap">' . 	
	$entryContent . '</div>' . '</html>';
	
	$entryContent = preg_replace("/\t/i", ' ', $entryContent);
	$entryContent = preg_replace("/\n/i", ' ', $entryContent);
	$entryContent = preg_replace("/class=\"unbox\"/i", 'class="unbox is-active"', $entryContent);
	
	if(strlen($entryContent)>131072){
		file_put_contents("$sid/htmls/$word", $entryContent);
		$entryContent = '<iframe marginwidth="20" marginheight="20" src="./htmls/' . $word . '.html' . '" width=800 height=500/></iframe>';
	}
	echo $entryContent;
	
	
	// GET TAG FROM WORD
	$tag = $word[0];
		
	// GET COPYRIGHT
	$copyRight = "Content of this flashcard is get from the Oxford Advanced Learner's Dictionary.<br>Thanks Oxford Dictionary! Thanks for using!";
	
	// GET FULL CONTENT FOR EACH CARD
	$ankiDeck = $word . "\t" . $wordType . "\t" . $phonetic . "\t" . $example . "\t" . $sound_uks[0] . "\t" . $sound_us[0] . "\t" . $thumb . "\t" . $img . "\t" . $entryContent . "\t" . $copyRight . "\t" . $tag . "\n";
	file_put_contents("$sid/ankiDeck.csv", $ankiDeck, FILE_APPEND | LOCK_EX);
}





// SUB FUNCTIONS

// returns a string with the HTML content from a DOMDocument node element ($elm)
function innerHTML(DOMNode $elm) { 
	$innerHTML = ''; 
	$children  = $elm->childNodes;
	
	foreach($children as $child) { 
		$innerHTML .= $elm->ownerDocument->saveHTML($child);
	}
	return $innerHTML;
}

// returns a string with the content of $url
function getContent($url) {
	$opts = array(
		'http' => array(
		'proxy' => 'tcp://192.168.103.62:3128',
		'request_fulluri' => True,
		),
	);
	
	$context = stream_context_create($opts);
	$content = file_get_contents($url, true, $context);
	return $content;
}

// returns a array of sound for flashcard & put sound files into folder
function getSounds($varSounds, $sid) {
	$sounds = array();
	$sound = "";
	if (isset($varSounds)){
		foreach($varSounds as $item) {
			$mp3Source = $item->getAttribute("data-src-mp3");
			$mp3FileContent = getContent($mp3Source);
			$mp3SourceSplited = explode('/',$mp3Source);
			$mp3SourceFileName = end($mp3SourceSplited);
			file_put_contents("$sid/sounds/$mp3SourceFileName", $mp3FileContent);
			$sound = "[sound:./sounds/$mp3SourceFileName]";
			array_push($sounds, $sound);
		}
	} else {
		$sounds = array();
	}
	return $sounds;
}

// returns a array of images for flashcard & put image files into folder
function getImages($parent, $tag, $att, $sid) {
	$imgs = array();
	$img = "";
	
	if (isset($parent)){
	$imgNodes = $parent->getElementsByTagName($tag);

		foreach($imgNodes as $item) {
			$imgSource = $item->getAttribute($att);
			$imgFileContent = getContent($imgSource);
			$imgSourceSplited = explode('/',$imgSource);
			if($tag==a){
				$imgSourceFileName = 'fullsize_' . end($imgSourceSplited);
			}else{
				$imgSourceFileName = end($imgSourceSplited);
			}
			file_put_contents("$sid/images/$imgSourceFileName", $imgFileContent);
			$img = '<img src="' . "./images/$imgSourceFileName" . '"/>';
			array_push($imgs, $img);
		}
	}else{
		$imgs = array();
	}
	return $imgs;
}

// returns a array of phonetics for flashcard
function getPhonetics($varPhonetics){
	$phonetics = array();
	$phonetic = "";
	if (isset($varPhonetics)){
		foreach($varPhonetics as $item) {
			$phonetic = innerHTML($item);
			$phonetic = '<span class="phon">' . $phonetic . '</span>';
			$phonetic = preg_replace("/<span class=\"wrap\">\/<\/span>/i", '', $phonetic);
			$phonetic = preg_replace("/<span class=\"bre\">BrE<\/span>/i", '', $phonetic);
			$phonetic = preg_replace("/<span class=\"name\">NAmE<\/span>/i", '', $phonetic);
			array_push($phonetics, $phonetic);
		}
	} else {
		$phonetics = array("There is no phonetic for this word!");
	}
	return $phonetics;
}


// returns a array of phonetics for flashcard
function getExamples($varExamples){
	$examples = array();
	$example = "";
	if (isset($varExamples)){
		foreach($varExamples as $item) {
			$example = innerHTML($item);
			$example = '<div class="x-g">' . $example . '</div>';
			array_push($examples, $example);
		}
	} else {
		$examples = array("There is no example for this word!");
	}
	return $examples;
}


// clear result
function recursiveRemoveDirectory($directory)
{
    foreach(glob("{$directory}/*") as $file)
    {
        if(is_dir($file)) { 
            recursiveRemoveDirectory($file);
        } else {
            unlink($file);
        }
    }
    rmdir($directory);
}

// zip result
function zpr( array $sources, $archivName, $destination, $zipObject){
	foreach($sources as $source){
		$files = array_diff(scandir($source), array('..', '.'));
		foreach($files as $file){			
			$src = "$source/$file";
			$des = "$destination/$src";
			if(is_dir($src)){
				$arraysrc = array($src);
				zpr($arraysrc, $archivName, $destination, $zipObject);
			}else{
				$zipObject->addFromString($des, file_get_contents($src));
			}
		}
	}
}

?>