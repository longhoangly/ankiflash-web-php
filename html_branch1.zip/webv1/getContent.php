<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
//error_reporting(E_ERROR);

// returns a string with the HTML content from a DOMDocument node element ($elm)
function innerHTML(DOMNode $elm) { 
	$innerHTML = ''; 
	$children  = $elm->childNodes;
	
	foreach($children as $child) { 
		$innerHTML .= $elm->ownerDocument->saveHTML($child);
	}
	
	return $innerHTML;
}


// get the q parameter from URL
//$q = $_GET["q"];
$q = $_REQUEST["q"];

if ($q !== "") {
	$opts = array(
		'http' => array(
		//'proxy' => 'tcp://192.168.103.62:3128',
		'request_fulluri' => True,
		),
	);
	
	$context = stream_context_create($opts);
	$url = "http://www.oxfordlearnersdictionaries.com/search/english/direct/?q=" . $q;
	$content = file_get_contents($url, true, $context);
	//$tmpfname = tempnam("./tmp", "foo" );
	//file_put_contents($tmpfname, $content, LOCK_EX);
	
	// create the DOMDocument object, and load HTML from $strhtml
	$dochtml = new DOMDocument();
	$dochtml->loadHTML($content);
	
	// get the element with id="entryContent"
	$entryContentHTML = $dochtml->getElementById('entryContent');
	
	// uses innerHTML() to get the HTML content from $entryContent
	$entryContent = innerHTML($entryContentHTML);
	$entryContent = '<html>' .
	'<meta http-equiv="Content-Type" content="text/html; charset=utf-8">' . 
	'<link type="text/css" rel="stylesheet" href="./oxlayout/oxford.css">' . 
	'<link type="text/css" rel="stylesheet" href="./oxlayout/interface.css">' . 
	'<link type="text/css" rel="stylesheet" href="./oxlayout/responsive.css">' .
	'<div id="entryContent" class="responsive_entry_center_wrap">' . 	
	$entryContent . '</div>' . '</html>';

}

// Output "no content" if no hint was found or output correct values 
echo $entryContent === "" ? "no content" : $entryContent;

?>