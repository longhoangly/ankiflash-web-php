<?php
error_reporting(E_ERROR);
//error_reporting(E_ALL);

// get the q parameter from URL
$q = $_REQUEST["q"];
$url = "http://www.oxfordlearnersdictionaries.com/search/english/direct/?q=" . $q;
$content = getContent($url);

// GET ENTRY CONTENT FROM OXFORD DICTIONARY
// create the DOMDocument object, and load HTML from $strhtml
$dochtml = new DOMDocument();
$dochtml->loadHTML($content);

// get the element with id="entryContent"
$entryContentHTML = $dochtml->getElementById('entryContent');

// uses innerHTML() to get the HTML content from $entryContent
if (isset($entryContentHTML )){
	$entryContent = innerHTML($entryContentHTML);
} else {
	$entryContent = "This word does not exist...!";
}

// link css and javascript file into entryContent div
$entryContent = '<html>' .
'<meta http-equiv="Content-Type" content="text/html; charset=utf-8">' . 
'<link type="text/css" rel="stylesheet" href="./oxlayout/oxford.css">' . 
'<link type="text/css" rel="stylesheet" href="./oxlayout/interface.css">' . 
'<link type="text/css" rel="stylesheet" href="./oxlayout/responsive.css">' .
'<div id="entryContent" class="responsive_entry_center_wrap">' . 	
$entryContent . '</div>' . '</html>';

// output "no content" if no content was found or output correct values 
echo $entryContent;


// GET PRONUNCIATION SOUND FILES
$xpath = new DOMXpath($dochtml);

$sounds = $xpath->query('//div[@class="sound audio_play_button pron-uk icon-audio"]', $entryContentHTML);
$sound_uk = getSound($sounds);
echo $sound_uk . "\n";

$sounds = $xpath->query('//div[@class="sound audio_play_button pron-us icon-audio"]', $entryContentHTML);
$sound_us = getSound($sounds);
echo $sound_us . "\n";























// SUB FUNCTIONS

// returns a string with the HTML content from a DOMDocument node element ($elm)
function innerHTML(DOMNode $elm) { 
	$innerHTML = ''; 
	$children  = $elm->childNodes;
	
	foreach($children as $child) { 
		$innerHTML .= $elm->ownerDocument->saveHTML($child);
	}
	return $innerHTML;
}

// returns a string with the content of $url
function getContent($url) {
	$opts = array(
		'http' => array(
		'proxy' => 'tcp://192.168.103.62:3128',
		'request_fulluri' => True,
		),
	);
	
	$context = stream_context_create($opts);
	$content = file_get_contents($url, true, $context);
	return $content;
}

// returns a link of sound for flashcard & put sounds file into folder
function getSound ($listNodes) {
	$sound = "";
	if (isset($listNodes)){
		foreach($listNodes as $item) {
			echo current($listNodes);
			$mp3Source = $item->getAttribute("data-src-mp3");
			$mp3FileContent = getContent($mp3Source);
			$mp3SourceSplited = explode('/',$mp3Source);
			$mp3SourceFileName = end($mp3SourceSplited);
			file_put_contents("./sounds/$mp3SourceFileName", $mp3FileContent);
			$sound = '[sound:' . $mp3SourceFileName . ']';
		}
	} else {
		$sound = "There is no sound...!";
	}
	return $sound;
}
?>