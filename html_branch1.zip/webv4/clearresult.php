<?php

function recursiveRemoveDirectory($directory)
{
    foreach(glob("{$directory}/*") as $file)
    {
        if(is_dir($file)) { 
            recursiveRemoveDirectory($file);
        } else {
            unlink($file);
        }
    }
    rmdir($directory);
}

recursiveRemoveDirectory("./complete");
recursiveRemoveDirectory("./images");
recursiveRemoveDirectory("./sounds");
recursiveRemoveDirectory("./htmls");
unlink("archive.zip");
unlink("ankiDeck.csv");

mkdir("images", 0777, true);
mkdir("sounds", 0777, true);
mkdir("htmls", 0777, true);

?>