<?php

$directories = array("icons", "oxlayout", "cardform", "sounds", "images", "htmls", "ankiDeck.csv");

$folderName = "complete";
$archivName = "archive.zip";
zp($directories, $archivName, $folderName);

function zp( array $source, $archivName, $destination){
	$zip = new ZipArchive; 
	$zip->open($archivName, ZipArchive::CREATE);
	
	$zip->addEmptyDir($destination); 
	foreach($source as $item){
		if(is_dir($item)){
			$des = "$destination/$item";
			$zip->addEmptyDir($des);
			$files = array_diff(scandir($item), array('..', '.'));
			foreach($files as $file){
				$url = "./$item/$file";
				$zip->addFromString("$des/$file", file_get_contents($url));
			}
		}else{
			$url = "./$item";
			$zip->addFromString("$destination/$item", file_get_contents($url));
		}
	}
}

$result = '<a href="http://localhost/html/archive.zip" style="font-size: 15px; color: blue">Download Archived Flashcard</a>';
echo $result;

/********************************>>>
$destination = "complete";
cp($directories, $destination);

function cp( array $source, $destination){
	mkdir($destination, 0777, true);
	foreach($source as $item){
		if(is_dir($item)){
			$des = "$destination/$item";
			mkdir($des, 0777, true);
			$files = array_diff(scandir($item), array('..', '.'));
			foreach($files as $file){
				$url = "./$item/$file";
				chmod($url, 0777);
				file_put_contents("$des/$file", file_get_contents($url));
			}
		}else{
			$url = "./$item";
			chmod($url, 0777);
			file_put_contents("$destination/$item", file_get_contents($url));
		}
	}
}
<<<********************************/

?>